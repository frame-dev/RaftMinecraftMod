# Raft Ocean addon starter SDK — 0.13.8

Unzip this folder, select a Java 25 JDK and run:

```powershell
.\gradlew.bat build --no-parallel
```

On Linux/macOS use `sh ./gradlew build --no-parallel`. First setup needs internet
for Gradle/NeoForge dependencies. Use `--offline` after dependencies are cached.
No parent checkout is needed: the exact main-mod jar is in libs and the Gradle
9.2.1 wrapper is included. Sources in libs can be attached in your IDE.

Output: build/libs/raft-example-addon-1.2.0.jar. Install it with the playable
libs/raft_ocean-0.13.8.jar on matching Minecraft26.3/NeoForge26.3.0.48-beta
client and server profiles. Do not install sources jars. Custom dev-client/server
run configurations are not supplied by this template.

Start with src/main/java/example/raftaddon/ExampleAddon.java and SedimentWasher.java.
The three complete examples cover a wide crate, persistent fuelled kelp dryer and
utility-powered sediment washer. Washer slot1 takes sand; slot2 produces clay.
Connect a raft generator and water tank/correct cables and pipes. A batch uses
one sand, ten FE and one cup of clean water. Sneak-use empty-handed to collect.
Recipes, models, language entries and dependency metadata are included.

Rename the example namespace/package, registrations and resources for your addon.
Update version/group, mod metadata and main-mod dependency range after testing.
Declare API interfaces through dev.raftocean.api; avoid depending on internal hosts.
Read docs/API_V3_UTILITIES.md and docs/MACHINE_ADDON_GUIDE.md for contracts/tests.

The example source/models retain MIT; the main mod is All Rights Reserved.
See LICENSE, LICENSE_NOTICE.txt, TEMPLATE_LICENSE.txt and licenses/GRADLE_LICENSE.txt.
Gradle wrapper notices also remain embedded in the supplied wrapper jar.
